﻿namespace WasdNClicky
{
    internal class PluginInfo
    {
        public const string GUID = "com.lucy.wasdnclicky";
        public const string Name = "WasdNClicky";
        public const string Version = "1.0.0";
    }
}