﻿using HarmonyLib;
using System.Reflection;
using GorillaNetworking;
using UnityEngine;

namespace WasdNClicky
{
    public static class HarmonyPatches
    {
        private static Harmony instance;

        public static bool IsPatched { get; private set; }
        public const string InstanceId = PluginInfo.GUID;

        public static void ApplyHarmonyPatches()
        {
            if (!IsPatched)
            {
                if (instance == null)
                    instance = new Harmony(InstanceId);

                instance.PatchAll(System.Reflection.Assembly.GetExecutingAssembly());
                IsPatched = true;
            }
        }

        /// <summary>
        /// Press any button component (VR button, keyboard button, custom key) safely.
        /// </summary>
        public static void PressButton(Component component)
        {
            if (component == null) return;

            string name = component.GetType().Name;

            if (name == "GorillaPressableButton" || name == "GorillaPlayerLineButton" || name == "CustomKeyboardKey")
            {
                MethodInfo onTrigger = component.GetType().GetMethod("OnTriggerEnter", BindingFlags.NonPublic | BindingFlags.Instance);
                if (onTrigger != null)
                    onTrigger.Invoke(component, new object[] { GetRightHandCollider() });
            }
            else if (name == "GorillaKeyboardButton")
            {
                var binding = Traverse.Create(component).Field("Binding").GetValue<GorillaKeyboardBindings>();
                GameEvents.OnGorrillaKeyboardButtonPressedEvent?.Invoke(binding);
            }
        }

        private static Collider GetRightHandCollider()
        {
            return GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/RightHandTriggerCollider")
                             ?.GetComponent<Collider>();
        }
    }
}
