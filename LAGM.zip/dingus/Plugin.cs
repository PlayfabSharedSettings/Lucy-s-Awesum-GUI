﻿using BepInEx;
using UnityEngine;
using UnityEngine.InputSystem;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using System.Collections.Generic;
using ExitGames.Client.Photon;

namespace WasdWithGUI
{
    [BepInPlugin("com.lucy.wasdgui", "WASD + GUI with Lobby Players Info", "17.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        private Rigidbody playerRb;
        private Transform turnParent;
        private Transform mainCamera;
        private Vector2 mouseLook;
        private float mouseSensitivity = 1.5f;
        private bool isLooking = false;
        private Rect windowRect = new Rect(20f, 20f, 400f, 300f);
        private bool guiOpen = true;
        private bool lastToggleState = false;
        private int currentTab = 0;
        private string playerName = "Player";
        private string colorR = "255";
        private string colorG = "128";
        private string colorB = "0";
        private string roomToJoin = "RoomCode";
        private int currentTheme = 1;
        private bool showPlayerDetails = true;
        private float mainTabHeight = 350f;
        private float miscTabHeight = 120f;
        private float lobbyTabHeight = 200f;
        private int lastPlayerCount = -1;
        private bool lastShowDetails = false;
        private string cachedLobbyText = "";
        private readonly Dictionary<string, string> coolPlayerList = new Dictionary<string, string>()
        {
            {"9DBC90CF7449EF64", "StyledSnailCY"},
            {"6FE5FF4D5DF68843", "Pine"},
            {"52529F0635BE0CDF", "PapaSmurf"},
            {"10D31D3BDCCE5B1F", "Deezey"},
            {"BAC5807405123060", "britishmonkeLU"}
        };
        private void Start()
        {
            var gorillaPlayerObj = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer");
            if (gorillaPlayerObj != null) playerRb = gorillaPlayerObj.GetComponent<Rigidbody>();
            turnParent = gorillaPlayerObj?.transform.Find("TurnParent");
            mainCamera = Camera.main?.transform;
            currentTheme = PlayerPrefs.GetInt("WasdGUI_Theme", 1);
        }
        private void FixedUpdate()
        {
            if (playerRb == null) return;
            float moveSpeed = 5f;
            if (Keyboard.current.leftShiftKey.isPressed) moveSpeed *= 2f;
            Vector3 forward = turnParent != null ? turnParent.forward : playerRb.transform.forward;
            Vector3 right = turnParent != null ? turnParent.right : playerRb.transform.right;
            Vector3 moveDir = Vector3.zero;
            if (Keyboard.current.wKey.isPressed) moveDir += forward;
            if (Keyboard.current.sKey.isPressed) moveDir -= forward;
            if (Keyboard.current.aKey.isPressed) moveDir -= right;
            if (Keyboard.current.dKey.isPressed) moveDir += right;
            if (Keyboard.current.spaceKey.isPressed) moveDir += Vector3.up;
            if (Keyboard.current.leftCtrlKey.isPressed) moveDir += Vector3.down;
            if (moveDir != Vector3.zero) playerRb.MovePosition(playerRb.position + moveDir.normalized * moveSpeed * Time.fixedDeltaTime);
        }
        private void LateUpdate()
        {
            if (mainCamera == null || turnParent == null) return;
            if (Mouse.current.rightButton.isPressed)
            {
                if (!isLooking)
                {
                    isLooking = true;
                    Cursor.lockState = CursorLockMode.Locked;
                    Cursor.visible = false;
                }
                Vector2 mouseDelta = Mouse.current.delta.ReadValue();
                mouseLook.x += mouseDelta.x * mouseSensitivity;
                mouseLook.y -= mouseDelta.y * mouseSensitivity;
                mouseLook.y = Mathf.Clamp(mouseLook.y, -80f, 80f);
                turnParent.localRotation = Quaternion.Euler(0f, mouseLook.x, 0f);
                mainCamera.localRotation = Quaternion.Euler(mouseLook.y, 0f, 0f);
            }
            else if (isLooking)
            {
                isLooking = false;
                Cursor.lockState = CursorLockMode.Confined;
                Cursor.visible = true;
            }
        }
        private void OnGUI()
        {
            bool toggleKey = Keyboard.current.backslashKey.isPressed;
            if (toggleKey && !lastToggleState) guiOpen = !guiOpen;
            lastToggleState = toggleKey;
            if (!guiOpen) return;
            ApplyTheme();
            windowRect = GUILayout.Window(0, windowRect, DrawWindow, "Lucy's Awsum GUI");
        }
        private void DrawWindow(int id)
        {
            GUILayout.BeginHorizontal();
            if (GUILayout.Toggle(currentTab == 0, "Main", GUI.skin.button)) currentTab = 0;
            if (GUILayout.Toggle(currentTab == 1, "Lobby Players", GUI.skin.button)) currentTab = 1;
            if (GUILayout.Toggle(currentTab == 2, "Misc", GUI.skin.button)) currentTab = 2;
            GUILayout.EndHorizontal();
            GUILayout.Space(10);
            switch (currentTab)
            {
                case 0: DrawMainTab(); break;
                case 1: DrawLobbyTab(); break;
                case 2: DrawMiscTab(); break;
            }
            GUI.DragWindow(new Rect(0, 0, windowRect.width, 20));
        }
        private void DrawMainTab()
        {
            float width = 200f;
            GUILayout.Label("Player Name:");
            playerName = GUILayout.TextField(playerName, GUILayout.Width(width));
            if (GUILayout.Button("Change Name", GUILayout.Width(width))) ChangePlayerName(playerName);
            GUILayout.Label("Color (RGB):");
            GUILayout.BeginHorizontal();
            colorR = GUILayout.TextField(colorR, GUILayout.Width(50));
            colorG = GUILayout.TextField(colorG, GUILayout.Width(50));
            colorB = GUILayout.TextField(colorB, GUILayout.Width(50));
            GUILayout.EndHorizontal();
            if (GUILayout.Button("Change Color", GUILayout.Width(width))) ChangePlayerColor(colorR, colorG, colorB);
            GUILayout.Label("Room To Join:");
            roomToJoin = GUILayout.TextField(roomToJoin, GUILayout.Width(width));
            if (GUILayout.Button("Join Custom Room", GUILayout.Width(width))) JoinRoom(roomToJoin);
            if (GUILayout.Button("Leave Lobby", GUILayout.Width(width))) PhotonNetwork.LeaveRoom();
            if (Mathf.Abs(windowRect.height - mainTabHeight) > 0.5f) windowRect.height = mainTabHeight;
        }
        private void DrawLobbyTab()
        {
            float width = 350f;
            showPlayerDetails = GUILayout.Toggle(showPlayerDetails, "Show Detailed Info", GUILayout.Width(width));
            if (!PhotonNetwork.InRoom)
            {
                GUILayout.Label("Not in a lobby.", GUILayout.Width(width));
                lobbyTabHeight = 200f;
            }
            else
            {
                GUILayout.TextArea(cachedLobbyText, GUILayout.Width(width), GUILayout.ExpandHeight(true));
                int playerCount = PhotonNetwork.PlayerList.Length;
                if (playerCount != lastPlayerCount || showPlayerDetails != lastShowDetails)
                {
                    lastPlayerCount = playerCount;
                    lastShowDetails = showPlayerDetails;
                    RebuildLobbyText();
                    float baseHeight = 200f;
                    float extra = playerCount * (showPlayerDetails ? 50f : 25f);
                    lobbyTabHeight = Mathf.Clamp(baseHeight + extra, baseHeight, Screen.height - 40f);
                }
            }
            if (Mathf.Abs(windowRect.height - lobbyTabHeight) > 0.5f) windowRect.height = lobbyTabHeight;
        }
        private void DrawMiscTab()
        {
            float width = 200f;
            GUILayout.Label("GUI Theme:");
            int newTheme = Mathf.RoundToInt(GUILayout.HorizontalSlider(currentTheme, 0, 6, GUILayout.Width(width)));
            if (newTheme != currentTheme)
            {
                currentTheme = newTheme;
                PlayerPrefs.SetInt("WasdGUI_Theme", currentTheme);
                PlayerPrefs.Save();
            }
            if (Mathf.Abs(windowRect.height - miscTabHeight) > 0.5f) windowRect.height = miscTabHeight;
        }
        private void ChangePlayerName(string newName)
        {
            if (PhotonNetwork.LocalPlayer != null) PhotonNetwork.LocalPlayer.NickName = newName;
        }
        private void ChangePlayerColor(string rStr, string gStr, string bStr)
        {
            if (float.TryParse(rStr, out float r) && float.TryParse(gStr, out float g) && float.TryParse(bStr, out float b))
            {
                Color color = new Color(r / 255f, g / 255f, b / 255f, 1f);
                PhotonNetwork.LocalPlayer.SetCustomProperties(new Hashtable { { "PlayerColor", color } });
            }
        }
        private void JoinRoom(string roomName)
        {
            if (PhotonNetworkController.Instance != null && !string.IsNullOrEmpty(roomName)) PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(roomName, JoinType.Solo);
        }
        private void ApplyTheme()
        {
            switch (currentTheme)
            {
                case 0: GUI.backgroundColor = Color.white; GUI.contentColor = Color.black; break;
                case 1: GUI.backgroundColor = new Color(0.3f, 0.3f, 0.3f); GUI.contentColor = Color.white; break;
                case 2: GUI.backgroundColor = new Color(0.2f, 0.2f, 0.6f); GUI.contentColor = Color.cyan; break;
                case 3: GUI.backgroundColor = new Color(0.1f, 0.3f, 0.1f); GUI.contentColor = Color.green; break;
                case 4: GUI.backgroundColor = new Color(0.4f, 0.1f, 0.1f); GUI.contentColor = Color.red; break;
                case 5: GUI.backgroundColor = Color.black; GUI.contentColor = Color.green; break;
            }
        }
        private void RebuildLobbyText()
        {
            if (!PhotonNetwork.InRoom || PhotonNetwork.PlayerList.Length == 0)
            {
                cachedLobbyText = "Not in a lobby.";
                return;
            }
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (var p in PhotonNetwork.PlayerList)
            {
                string displayName = p.NickName ?? "<no-name>";
                sb.AppendLine(displayName);
                if (!string.IsNullOrEmpty(p.UserId) && coolPlayerList.ContainsKey(p.UserId)) sb.AppendLine($"{coolPlayerList[p.UserId]} is a cool person!");
                if (showPlayerDetails)
                {
                    sb.AppendLine($"ID: {p.UserId ?? p.ActorNumber.ToString()}");
                    foreach (var kvp in p.CustomProperties) sb.AppendLine($"{kvp.Key}: {kvp.Value}");
                }
                sb.AppendLine();
            }
            cachedLobbyText = sb.ToString();
        }
    }
}
